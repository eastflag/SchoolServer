package com.aura.smartschool;

public final class Constant {
	public final static String Weight = "Weight"; 
	public final static String Height = "Height";
	public final static String BMI = "BMI";
}
