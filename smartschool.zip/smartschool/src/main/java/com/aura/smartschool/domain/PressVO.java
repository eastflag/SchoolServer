package com.aura.smartschool.domain;

public class PressVO {
	private int press_id;
	private String title;
	private String content;
	private String created;
	
	public int getPress_id() {
		return press_id;
	}
	public void setPress_id(int press_id) {
		this.press_id = press_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}

}
