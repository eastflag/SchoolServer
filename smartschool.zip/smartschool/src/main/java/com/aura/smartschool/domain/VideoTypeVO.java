package com.aura.smartschool.domain;

public class VideoTypeVO {
	private String masterGradeId;
	private String infoType;
	private String section;
	
	public String getMasterGradeId() {
		return masterGradeId;
	}
	public void setMasterGradeId(String masterGradeId) {
		this.masterGradeId = masterGradeId;
	}
	public String getInfoType() {
		return infoType;
	}
	public void setInfoType(String infoType) {
		this.infoType = infoType;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
}
