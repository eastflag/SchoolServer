package com.aura.smartschool.domain;

public class ConsultHistoryVO {
	private int progress;
	private int complete;
	
	public int getProgress() {
		return progress;
	}
	public void setProgress(int progress) {
		this.progress = progress;
	}
	public int getComplete() {
		return complete;
	}
	public void setComplete(int complete) {
		this.complete = complete;
	}
}
