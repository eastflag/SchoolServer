package com.aura.smartschool.domain;

public class HomeVO {
	private String home_id;
	private int use_yn;
	private String created;
	private String updated;

	public String getHome_id() {
		return home_id;
	}

	public void setHome_id(String home_id) {
		this.home_id = home_id;
	}

	public int getUse_yn() {
		return use_yn;
	}

	public void setUse_yn(int use_yn) {
		this.use_yn = use_yn;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getUpdated() {
		return updated;
	}

	public void setUpdated(String updated) {
		this.updated = updated;
	}
	
	
}
